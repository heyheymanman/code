# coding=gbk
'''
Created on 2016��5��7��

@author: lenovo
'''
import xlrd#����ģ��
data = xlrd.open_workbook('sheet.xlsx')#��excel�ļ���ȡ����
table =data.sheets()[0]#��ȡһ��������
from statistics import mean,variance
print('��һ�еľ�ֵ=',mean(table.col_values(0)))
print('�ڶ��еľ�ֵ=',mean(table.col_values(1)))
print('�����еľ�ֵ=',mean(table.col_values(2)))
print('�����еľ�ֵ=',mean(table.col_values(3)))
print('�����еľ�ֵ=',mean(table.col_values(4)))
print('�����еľ�ֵ=',mean(table.col_values(5)))
print('�����еľ�ֵ=',mean(table.col_values(6)))
print('�ڰ��еľ�ֵ=',mean(table.col_values(7)))
print('��һ�еķ���=',variance(table.col_values(0)))
print('�ڶ��еķ���=',variance(table.col_values(1)))
print('�����еķ���=',variance(table.col_values(2)))
print('�����еķ���=',variance(table.col_values(3)))
print('�����еķ���=',variance(table.col_values(4)))
print('�����еķ���=',variance(table.col_values(5)))
print('�����еķ���=',variance(table.col_values(6)))
print('�ڰ��еķ���=',variance(table.col_values(7)))
import math 
import matplotlib.pyplot as t 
import numpy as n
import matplotlib.pylab as pl
import matplotlib.lines as mlines
from matplotlib.legend_handler import HandlerLine2D
def linefit(x,y):#�������Իع麯��
    N = len(x)
    sx,sy,sxx,syy,sxy=0,0,0,0,0
    for i in range(0,N):
        sx+=x[i]
        sy+=y[i]
        sxx+=x[i]*x[i]
        syy+=y[i]*y[i]
        sxy+=x[i]*y[i]
    a=(sy*sx/N-sxy)/(sx*sx/N-sxx)
    b=(sy-a*sx)/N
    r=abs(sy*sx/N-sxy)/math.sqrt((sxx-sx*sx/N)*(syy-sy*sy/N))
    return a,b,r
X1=table.col_values(0)
Y1=table.col_values(1)
a1,b1,r1=linefit(X1,Y1)
print('ʵ�����ݣ�')
print('X=',X1)
print('Y=',Y1)
print('��Ͻ����y=',a1,'x+',b1,'y,r=',r1)
X2=table.col_values(2)
Y2=table.col_values(3)
a2,b2,r2=linefit(X2,Y2)
print('ʵ�����ݣ�')
print('X=',X2)
print('Y=',Y2)
print('��Ͻ����y=',a2,'x+',b2,'y,r=',r2)
X3=table.col_values(4)
Y3=table.col_values(5)
a3,b3,r3=linefit(X3,Y3)
print('ʵ�����ݣ�')
print('X=',X3)
print('Y=',Y3)
print('��Ͻ����y=',a3,'x+',b3,'y,r=',r3)
X4=table.col_values(6)
Y4=table.col_values(7)
a4,b4,r4=linefit(X4,Y4)
print('ʵ�����ݣ�')
print('X=',X4)
print('Y=',Y4)
print('��Ͻ����y=',a4,'x+',b4,'y,r=',r4)
fig=t.figure()
t.figure(1)
t.title('figure')
ax1=t.subplot(221)
ax2=t.subplot(222)
ax3=t.subplot(223)
ax4=t.subplot(224)
t.sca(ax1)
t.xlabel('x')
t.ylabel('y')
t.title('Arecombe1')
ax1.plot(table.col_values(0), table.col_values(1),'bo')#��ɢ��ͼ
x1 = n.array(table.col_values(0))
y1 = n.array(table.col_values(1))
a1,b1 = n.polyfit(x1, y1, 1)
predicted_y1 = n.array(x1) + b1
line1,=ax1.plot(x1, predicted_y1,'k',label='linear y=0.50009*x+3.00009') #�������ֱ��
blue_line = mlines.Line2D([], [], color='blue', marker='.',
                          markersize=15, label='Arecombe1 txt')

# Create a legend for the first line.
first_legend = t.legend(handles=[blue_line], loc=8)

# Add the legend manually to the current Axes.
ax= t.gca().add_artist(first_legend)

# Create another legend for the second line.
t.legend(handles=[line1], loc=1)

t.sca(ax2)
t.xlabel('x')
t.ylabel('y')
t.title('Arecombe2')
plot3=t.plot(table.col_values(2), table.col_values(3),'bo')#��ɢ��ͼ
x2 = n.array(table.col_values(2))
y2 = n.array(table.col_values(3))
a2,b2 = n.polyfit(x2, y2, 1)
predicted_y2 = n.array(x2) + b2
line2,=t.plot(x2, predicted_y2,'k',label='linear y=0.5*x+3.0009') #�������ֱ��
blue_line = mlines.Line2D([], [], color='blue', marker='.',
                          markersize=15, label='Arecombe2 txt')

# Create a legend for the first line.
first_legend = t.legend(handles=[blue_line], loc=8)

# Add the legend manually to the current Axes.
ax= t.gca().add_artist(first_legend)

# Create another legend for the second line.
t.legend(handles=[line2], loc=1)
t.sca(ax3)
t.xlabel('x')
t.ylabel('y')
t.title('Arecombe3')
t.plot(table.col_values(4), table.col_values(5),'bo')#��ɢ��ͼ
x3 = n.array(table.col_values(4))
y3 = n.array(table.col_values(5))
a3,b3 = n.polyfit(x3, y3, 1)
predicted_y3 = n.array(x3) + b3
line3,=t.plot(x3, predicted_y3,'k',label='linear y=0.49973*x+3.00245') #�������ֱ��
blue_line = mlines.Line2D([], [], color='blue', marker='.',
                          markersize=15, label='Arecombe3 txt')

# Create a legend for the first line.
first_legend = t.legend(handles=[blue_line], loc=8)

# Add the legend manually to the current Axes.
ax= t.gca().add_artist(first_legend)

# Create another legend for the second line.
t.legend(handles=[line3], loc=1)
t.sca(ax4)
t.xlabel('x')
t.ylabel('y')
t.title('Arecombe4')
t.plot(table.col_values(6), table.col_values(7),'bo')#��ɢ��ͼ
x4 = n.array(table.col_values(6))
y4 = n.array(table.col_values(7))
a4,b4 = n.polyfit(x4, y4, 1)
predicted_y4= n.array(x4) + b4
line4,=t.plot(x4, predicted_y4,'k',label='linear y=0.4999*x+3.0017') #�������ֱ��
blue_line = mlines.Line2D([], [], color='blue', marker='.',
                          markersize=15, label='Arecombe4 txt')

# Create a legend for the first line.
first_legend = t.legend(handles=[blue_line], loc=8)

# Add the legend manually to the current Axes.
ax= t.gca().add_artist(first_legend)

# Create another legend for the second line.
t.legend(handles=[line4], loc=1)
    
t.show()